/**
 * WSA API adapter for Cloudflare Pages.
 * Paste this whole file as a NEW Apps Script file named Api.gs.
 * Do not replace the existing Code.gs, and do not delete doGet().
 * Set Script Property WSA_API_SECRET to a long random secret.
 */
function doPost(e) {
  try {
    var raw = e && e.postData && e.postData.contents ? e.postData.contents : '';
    if (!raw) throw new Error('Permintaan API kosong.');
    var request;
    try { request = JSON.parse(raw); }
    catch (parseError) { throw new Error('Format JSON API tidak valid.'); }

    var expectedSecret = PropertiesService.getScriptProperties().getProperty('WSA_API_SECRET');
    if (!expectedSecret || String(request.apiSecret || '') !== expectedSecret) {
      throw new Error('Akses API ditolak. Periksa WSA_API_SECRET pada konfigurasi server.');
    }

    var method = String(request.method || '');
    var args = Array.isArray(request.args) ? request.args : [];
    var result = dispatchWsaApi_(method, args);
    return wsaApiJson_({ ok: true, result: result });
  } catch (err) {
    return wsaApiJson_({
      ok: false,
      error: String(err && err.message ? err.message : err)
    });
  }
}

/** Allow-list eksplisit: hanya metode di bawah yang dapat dipanggil melalui API. */
function dispatchWsaApi_(method, args) {
  switch (method) {
    case 'getAppStatus': return getAppStatus();
    case 'getPublicBootstrap': return getPublicBootstrap();
    case 'searchPublicPlayers': return searchPublicPlayers(args[0]);
    case 'beginRegistration': return beginRegistration(args[0]);
    case 'uploadRegistrationFile': return uploadRegistrationFile(args[0], args[1]);
    case 'completeRegistration': return completeRegistration(args[0]);
    case 'cancelRegistration': return cancelRegistration(args[0]);
    case 'authenticateAdmin': return authenticateAdmin(args[0]);
    case 'loadAdminData': return loadAdminData(args[0]);
    case 'loadAdminDataForTab': return loadAdminDataForTab(args[0], args[1]);
    case 'saveNarrative': return saveNarrative(args[0], args[1]);
    case 'changeAdminPassword': return changeAdminPassword(args[0], args[1], args[2]);
    case 'changePlayerStatus': return changePlayerStatus(args[0], args[1], args[2]);
    case 'deletePlayerRecord': return deletePlayerRecord(args[0], args[1]);
    case 'beginPlayerEdit': return beginPlayerEdit(args[0], args[1], args[2]);
    case 'uploadPlayerEditFile': return uploadPlayerEditFile(args[0], args[1], args[2]);
    case 'finishPlayerEdit': return finishPlayerEdit(args[0], args[1]);
    case 'cancelPlayerEdit': return cancelPlayerEdit(args[0], args[1]);
    case 'saveAttendance': return saveAttendance(args[0], args[1]);
    case 'clearTodayAttendance': return clearTodayAttendance(args[0]);
    case 'saveEvaluation': return saveEvaluation(args[0], args[1]);
    case 'deleteEvaluationRecord': return deleteEvaluationRecord(args[0], args[1]);
    case 'addNews': return addNews(args[0], args[1]);
    case 'addGallery': return addGallery(args[0], args[1]);
    case 'saveAgeCategories': return saveAgeCategories(args[0], args[1]);
    case 'deleteNewsRecord': return deleteNewsRecord(args[0], args[1]);
    case 'deleteGalleryRecord': return deleteGalleryRecord(args[0], args[1]);
    default: throw new Error('Metode API tidak diizinkan: ' + method);
  }
}

function wsaApiJson_(object) {
  return ContentService
    .createTextOutput(JSON.stringify(object))
    .setMimeType(ContentService.MimeType.JSON);
}
