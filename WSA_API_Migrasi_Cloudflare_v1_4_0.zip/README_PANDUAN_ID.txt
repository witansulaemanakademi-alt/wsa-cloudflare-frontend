WSA API MIGRATION v1.4.0 — CLOUDFARE PAGES + GOOGLE APPS SCRIPT

ISI PAKET
- public/index.html: frontend statis terbaru, apiCall sudah menggunakan fetch('/api').
- functions/api.js: Cloudflare Pages Function untuk proxy API, allow-list metode.
- Api.gs: tambahan backend API untuk ditempel sebagai file BARU bernama Api.gs pada proyek Apps Script yang sudah ada.
- Index_Cloudflare.html: salinan frontend di luar folder public untuk akses mudah.

PENTING
1. JANGAN mengganti Code.gs yang sudah ada. Tambahkan Api.gs sebagai file baru di proyek Apps Script yang sama.
2. JANGAN menjalankan setupApp_ lagi. Database dan folder Drive yang ada tetap digunakan.
3. Jangan menaruh API secret di GitHub atau HTML. Jangan kirim secret melalui chat.
4. File frontend statis berbeda dari HTML Index pada proyek Apps Script. Jangan ganti Index Apps Script dengan public/index.html; simpan frontend statis hanya di GitHub/Cloudflare Pages.

TAHAP A — BACKUP
- Di Apps Script, buat salinan proyek atau salin Code.gs dan Index lama ke file backup lokal.
- Catat URL Web App /exec aktif.
- Pastikan database/Drive bisa diakses sebelum lanjut.

TAHAP B — API SECRET DI APPS SCRIPT
1. Buka proyek Apps Script yang sekarang dipakai.
2. Klik + di sebelah Files, pilih Script, beri nama Api.
3. Buka file Api.gs dari paket ini, salin seluruh isinya ke file Api pada Apps Script.
4. Klik Project Settings (ikon roda gigi) > Script Properties > Add script property.
5. Tambahkan nama WSA_API_SECRET dan nilai rahasia acak panjang (minimal 32 karakter). Buat sendiri menggunakan password manager; jangan gunakan password admin dan jangan bagikan.
6. Simpan. Jangan menghapus Script Properties yang sudah ada.
7. Klik Deploy > Manage deployments > Edit deployment Web App yang lama > New version > Deploy. Pertahankan URL /exec jika memperbarui deployment yang sama.
8. Pengaturan Web App biasanya harus Execute as: Me dan Who has access: Anyone untuk menerima request dari Cloudflare. Secret API membatasi akses doPost; tetap gunakan fungsi admin yang memeriksa token.

TAHAP C — BUAT REPOSITORY GITHUB
1. Buat repository privat, contoh wsa-cloudflare-frontend.
2. Upload dua item dari paket dengan struktur persis:
   public/index.html
   functions/api.js
   Catatan: folder functions berada di root repository, sejajar dengan public, bukan di dalam public.
3. Jangan upload Api.gs ke frontend/GitHub dan jangan upload secret.
4. Commit changes.

TAHAP D — CLOUDFLARE PAGES
1. Buka Cloudflare Dashboard > Workers & Pages > Create application > Pages > Connect to Git.
2. Hubungkan GitHub, pilih repository wsa-cloudflare-frontend, lalu Begin setup.
3. Framework preset: None. Production branch: main. Build command: exit 0. Build output directory: public. Root directory: kosong.
4. Klik Save and Deploy. Pages akan memberi alamat *.pages.dev. Alamat workers.dev yang lama tetap milik Worker lama; tidak otomatis menjadi alamat Pages.

TAHAP E — VARIABEL SERVER DI PAGES
1. Pada proyek Pages baru, buka Settings > Variables and Secrets (atau Settings > Environment variables).
2. Tambahkan GAS_API_URL (Text/Variable) dengan URL Web App /exec dari tahap B, misalnya URL Apps Script Anda yang berakhiran /exec.
3. Tambahkan WSA_API_SECRET sebagai Type Secret, dengan nilai PERSIS sama seperti Script Property di Apps Script.
4. Tambahkan untuk Production; jika menguji Preview deployment, tambahkan juga pada Preview environment.
5. Simpan lalu trigger redeploy terbaru.

TAHAP F — UJI
1. Buka https://NAMA-PROJECT.pages.dev/api. Harus tampil JSON: {"ok":true,"service":"WSA API proxy",...}.
2. Buka website utama *.pages.dev; beranda harus tampil.
3. Tes Cek Status, login admin, berita/galeri, pendaftaran, satu upload file, penilaian, rapor, edit dan hapus berita/galeri.
4. Jangan langsung melakukan pendaftaran dengan data nyata saat tes awal. Gunakan data uji dan pastikan data/foldernya memang tercatat.
5. Jika API mengembalikan error, buka DevTools > Console dan Network, pilih POST /api, lihat Response tanpa membagikan secret apa pun. Periksa juga Apps Script > Executions.

CATATAN PEMULIHAN
- Deployment Apps Script lama tetap pertahankan untuk rollback.
- Jangan mengganti Index.html di dalam Apps Script; itu dipakai URL lama dan menjadi cadangan.
- Jika terjadi error, rollback repository ke commit sebelumnya dan tetap gunakan URL Apps Script lama sementara.

PENJELASAN KEAMANAN
- Secret berada hanya di Script Properties dan Cloudflare Pages Secret, tidak pernah di HTML/GitHub.
- Admin tetap harus login; fungsi backend yang sensitif harus tetap memanggil requireAdmin_(token).
- API publik seperti pendaftaran/search dapat dipanggil dari internet; tambahkan rate limiting/challenge sebelum skala besar.
- API adapter saat ini hanya mengizinkan daftar method eksplisit. Jangan menambahkan dispatch semua fungsi berdasarkan nama yang dikirim client.
